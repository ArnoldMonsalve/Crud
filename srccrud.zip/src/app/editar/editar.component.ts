import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmpleadosService } from '../ver/empleados.service';

@Component({
  selector: 'app-editar',
  templateUrl: './editar.component.html',
  styleUrls: ['./editar.component.css']
})
export class EditarComponent implements OnInit {
  info:any=[];
  cargada=false;
  paramid:any;
  nombre:string='';
  apellido:string='';
  sexo:string='';
  email:string='';

  constructor(private router: Router,private idurl: ActivatedRoute, private Empleados: EmpleadosService) { }

  //boton de regresar usando navigate metodo añadido por el constructor nombrada Router
  llevameQuieroRegresar(){
  this.router.navigateByUrl('/ver')
  }

  //recibimos el id desde la url y luego lo guardamos en ina variable global en este caso paramid y llamamos la funcion que recorre la api para traer los datos
  ngOnInit(): void {
    this.paramid=this.idurl.snapshot.params;
    this.datosdelEmpleado();
  }

  //se trae los datos del empleado y filtra por el id que recibe de la url y llama la funcion buscar la cual se encarga de recibir el id
  datosdelEmpleado(){
    this.Empleados.buscarid(this.idurl.snapshot.paramMap.get('id')).subscribe(data => {
      this.info=data;
      this.cargada=true;
      console.log(data);
      //for que recorre la informacion traida del backen donde por medio de un if friltrara la informacion de la api buscando el id que se selecciono y fue guardado en la variable paramid
      for(let i=0;i<this.info.length;i++){
        if(this.info[i].id==this.paramid.id){
          this.nombre= this.info[i].nombre;
          this.apellido= this.info[i].apellido;
          this.email= this.info[i].email;
          this.sexo= this.info[i].sexo;
        }
      }
    });
  }
}
